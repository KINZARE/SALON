import "server-only";
import { differenceInCalendarDays } from "date-fns";
import { formatInTimeZone, fromZonedTime } from "date-fns-tz";
import { computeAvailability, type Interval } from "@/domain/availability";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { isPreviewDemoMode } from "@/lib/preview-mode";
import { PREVIEW_DEMO, getDemoAvailability } from "@/demo/preview-data";

export type PublicSalon = {
  id: string;
  slug: string;
  name: string;
  timezone: string;
  currency: string;
  allowStaffChoice: boolean;
};

export type PublicService = {
  id: string;
  name: string;
  description: string | null;
  durationMinutes: number;
  priceCents: number;
  currency: string;
};

export type PublicStaff = { id: string; name: string };

export type PublicAvailability = {
  salon: PublicSalon;
  staff: PublicStaff[];
  slots: Array<{ start: string; serviceEnd: string; staffIds: string[] }>;
};

type ServiceRow = {
  id: string;
  salon_id: string;
  name: string;
  description: string | null;
  duration_minutes: number;
  price_cents: number;
  currency: string;
  buffer_minutes: number;
  active: boolean;
  online_bookable: boolean;
};

type StaffRow = { id: string; name: string; active: boolean };
type TimeRow = { start_time: string; end_time: string };
type TimedRow = { starts_at: string; ends_at: string };
type AppointmentRow = { staff_id: string; starts_at: string; occupied_until: string };

function asLocalInterval(date: string, timezone: string, row: TimeRow): Interval {
  return {
    start: fromZonedTime(`${date}T${row.start_time}`, timezone),
    end: fromZonedTime(`${date}T${row.end_time}`, timezone),
  };
}

function isoInterval(row: TimedRow): Interval {
  return { start: new Date(row.starts_at), end: new Date(row.ends_at) };
}

async function getSalonBySlug(slug: string): Promise<PublicSalon | null> {
  if (isPreviewDemoMode()) {
    if (slug !== PREVIEW_DEMO.salon.slug) return null;
    return {
      id: PREVIEW_DEMO.salon.id, slug: PREVIEW_DEMO.salon.slug, name: PREVIEW_DEMO.salon.name,
      timezone: PREVIEW_DEMO.salon.timezone, currency: PREVIEW_DEMO.salon.currency, allowStaffChoice: PREVIEW_DEMO.salon.allowStaffChoice,
    };
  }
  const db = createAdminSupabaseClient();
  const { data, error } = await db
    .from("salons")
    .select("id,slug,name,timezone,currency")
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;

  const settings = await db
    .from("booking_settings")
    .select("allow_staff_choice")
    .eq("salon_id", data.id)
    .maybeSingle();
  if (settings.error) throw settings.error;

  return {
    ...data,
    allowStaffChoice: settings.data?.allow_staff_choice ?? true,
  };
}

export async function getPublicSalon(slug: string) {
  return getSalonBySlug(slug);
}

export async function getPublicServices(salonId: string): Promise<PublicService[]> {
  if (isPreviewDemoMode()) {
    if (salonId !== PREVIEW_DEMO.salon.id) return [];
    return PREVIEW_DEMO.services.filter((service) => service.active && service.online_bookable).map((service) => ({
      id: service.id, name: service.name, description: service.description, durationMinutes: service.durationMinutes, priceCents: service.priceCents, currency: service.currency,
    }));
  }
  const db = createAdminSupabaseClient();
  const { data, error } = await db
    .from("services")
    .select("id,name,description,duration_minutes,price_cents,currency")
    .eq("salon_id", salonId)
    .eq("active", true)
    .eq("online_bookable", true)
    .order("name");
  if (error) throw error;
  return (data ?? []).map((row) => ({
    id: row.id,
    name: row.name,
    description: row.description,
    durationMinutes: row.duration_minutes,
    priceCents: row.price_cents,
    currency: row.currency,
  }));
}

export async function getPublicStaffForService(salonId: string, serviceId: string): Promise<PublicStaff[]> {
  if (isPreviewDemoMode()) {
    if (salonId !== PREVIEW_DEMO.salon.id || !PREVIEW_DEMO.services.some((service) => service.id === serviceId && service.active)) return [];
    return PREVIEW_DEMO.staff.filter((member) => member.active).map(({ id, name }) => ({ id, name }));
  }
  const db = createAdminSupabaseClient();
  const { data: links, error: linksError } = await db
    .from("staff_services")
    .select("staff_id")
    .eq("salon_id", salonId)
    .eq("service_id", serviceId);
  if (linksError) throw linksError;
  const ids = (links ?? []).map((link) => link.staff_id);
  if (!ids.length) return [];

  const { data, error } = await db
    .from("staff")
    .select("id,name,active")
    .eq("salon_id", salonId)
    .eq("active", true)
    .in("id", ids)
    .order("name");
  if (error) throw error;
  return (data ?? []).map((row) => ({ id: row.id, name: row.name }));
}

export async function getAvailableSlotsForDate(args: {
  salonSlug: string;
  serviceId: string;
  date: string;
  staffId?: string | null;
  source?: "public" | "internal";
}): Promise<PublicAvailability> {
  if (isPreviewDemoMode()) {
    const salon = await getSalonBySlug(args.salonSlug);
    if (!salon) throw new Error("SALON_NOT_FOUND");
    const service = PREVIEW_DEMO.services.find((item) => item.id === args.serviceId && item.active && ((args.source ?? "public") === "internal" || item.online_bookable));
    if (!service) throw new Error("SERVICE_NOT_FOUND");
    const staff = await getPublicStaffForService(salon.id, service.id);
    if (args.staffId && !staff.some((member) => member.id === args.staffId)) return { salon, staff, slots: [] };
    return { salon, staff, slots: getDemoAvailability(args.date, args.staffId, service.durationMinutes) };
  }
  const db = createAdminSupabaseClient();
  const salon = await getSalonBySlug(args.salonSlug);
  if (!salon) throw new Error("SALON_NOT_FOUND");

  const { data: serviceData, error: serviceError } = await db
    .from("services")
    .select("id,salon_id,name,description,duration_minutes,price_cents,currency,buffer_minutes,active,online_bookable")
    .eq("id", args.serviceId)
    .eq("salon_id", salon.id)
    .eq("active", true)
    .maybeSingle();
  if (serviceError) throw serviceError;
  if (!serviceData) throw new Error("SERVICE_NOT_FOUND");
  const service = serviceData as ServiceRow;
  if ((args.source ?? "public") === "public" && !service.online_bookable) throw new Error("SERVICE_NOT_FOUND");

  const settingsResult = await db
    .from("booking_settings")
    .select("slot_interval_minutes,min_lead_minutes,max_days_ahead,allow_staff_choice")
    .eq("salon_id", salon.id)
    .maybeSingle();
  if (settingsResult.error) throw settingsResult.error;
  const settings = settingsResult.data ?? {
    slot_interval_minutes: 15,
    min_lead_minutes: 60,
    max_days_ahead: 90,
    allow_staff_choice: true,
  };

  const todayLocal = formatInTimeZone(new Date(), salon.timezone, "yyyy-MM-dd");
  const requestedCalendarDate = new Date(`${args.date}T12:00:00Z`);
  const todayCalendarDate = new Date(`${todayLocal}T12:00:00Z`);
  const daysAhead = differenceInCalendarDays(requestedCalendarDate, todayCalendarDate);
  if (daysAhead < 0 || daysAhead > settings.max_days_ahead) {
    return { salon, staff: [], slots: [] };
  }

  const weekday = requestedCalendarDate.getUTCDay();
  const nextCalendarDate = new Date(requestedCalendarDate.getTime() + 86_400_000).toISOString().slice(0, 10);
  const dayStart = fromZonedTime(`${args.date}T00:00:00`, salon.timezone);
  const dayEnd = fromZonedTime(`${nextCalendarDate}T00:00:00`, salon.timezone);

  const staff = await getPublicStaffForService(salon.id, service.id);
  const eligibleStaff = args.staffId ? staff.filter((member) => member.id === args.staffId) : staff;
  if (!eligibleStaff.length) return { salon, staff, slots: [] };
  const staffIds = eligibleStaff.map((member) => member.id);

  const [openingResult, scheduleResult, breaksResult, blocksResult, appointmentsResult] = await Promise.all([
    db.from("opening_hours").select("start_time,end_time").eq("salon_id", salon.id).eq("weekday", weekday).eq("is_open", true).maybeSingle(),
    db.from("staff_schedules").select("staff_id,start_time,end_time").eq("salon_id", salon.id).eq("weekday", weekday).eq("is_working", true).in("staff_id", staffIds),
    db.from("breaks").select("staff_id,start_time,end_time").eq("salon_id", salon.id).eq("weekday", weekday).eq("active", true).in("staff_id", staffIds),
    db.from("blocks").select("staff_id,starts_at,ends_at").eq("salon_id", salon.id).lt("starts_at", dayEnd.toISOString()).gt("ends_at", dayStart.toISOString()),
    db.from("appointments").select("staff_id,starts_at,occupied_until").eq("salon_id", salon.id).in("staff_id", staffIds).in("status", ["pending", "confirmed", "checked_in"]).lt("starts_at", dayEnd.toISOString()).gt("occupied_until", dayStart.toISOString()),
  ]);

  for (const result of [openingResult, scheduleResult, breaksResult, blocksResult, appointmentsResult]) {
    if (result.error) throw result.error;
  }
  if (!openingResult.data) return { salon, staff, slots: [] };

  const salonWindow = asLocalInterval(args.date, salon.timezone, openingResult.data as TimeRow);
  const minStart = (args.source ?? "public") === "public"
    ? new Date(Date.now() + settings.min_lead_minutes * 60_000)
    : new Date();

  const availability = computeAvailability({
    serviceDurationMinutes: service.duration_minutes,
    bufferMinutes: service.buffer_minutes,
    slotIntervalMinutes: settings.slot_interval_minutes,
    minStart,
    staff: eligibleStaff.map((member) => {
      const schedule = (scheduleResult.data ?? []).find((row) => row.staff_id === member.id);
      const staffBreaks = (breaksResult.data ?? []).filter((row) => row.staff_id === member.id);
      const staffBlocks = (blocksResult.data ?? []).filter((row) => row.staff_id === null || row.staff_id === member.id);
      const staffAppointments = (appointmentsResult.data ?? []).filter((row) => row.staff_id === member.id) as AppointmentRow[];
      return {
        staffId: member.id,
        salonOpen: [salonWindow],
        staffWorking: schedule ? [asLocalInterval(args.date, salon.timezone, schedule as TimeRow)] : [],
        breaks: staffBreaks.map((row) => asLocalInterval(args.date, salon.timezone, row as TimeRow)),
        blocks: staffBlocks.map((row) => isoInterval(row as TimedRow)),
        appointments: staffAppointments.map((row) => ({ start: new Date(row.starts_at), end: new Date(row.occupied_until) })),
      };
    }),
  });

  return {
    salon,
    staff,
    slots: availability.map((slot) => ({
      start: slot.start.toISOString(),
      serviceEnd: slot.serviceEnd.toISOString(),
      staffIds: slot.staffIds,
    })),
  };
}

export async function createPublicBooking(args: {
  salonSlug: string;
  serviceId: string;
  staffId?: string | null;
  startsAt: string;
  customer: { name: string; phone: string; email: string; note?: string | null };
}) {
  const salon = await getSalonBySlug(args.salonSlug);
  if (!salon) throw new Error("SALON_NOT_FOUND");

  const startsAt = new Date(args.startsAt);
  if (Number.isNaN(startsAt.getTime())) throw new Error("INVALID_START_TIME");
  const date = formatInTimeZone(startsAt, salon.timezone, "yyyy-MM-dd");
  const current = await getAvailableSlotsForDate({
    salonSlug: args.salonSlug,
    serviceId: args.serviceId,
    date,
    staffId: args.staffId,
    source: "public",
  });
  const exact = current.slots.find((slot) => slot.start === startsAt.toISOString());
  if (!exact) throw new Error("SLOT_UNAVAILABLE");

  const candidates = args.staffId ? [args.staffId] : exact.staffIds;
  if (!candidates.length) throw new Error("SLOT_UNAVAILABLE");

  if (isPreviewDemoMode()) {
    return { appointmentId: PREVIEW_DEMO.bookedAppointmentId, staffId: candidates[0] };
  }

  const db = createAdminSupabaseClient();
  let lastConflict = false;
  for (const candidateStaffId of candidates) {
    const { data, error } = await db.rpc("create_appointment_atomic", {
      p_salon_id: salon.id,
      p_service_id: args.serviceId,
      p_staff_id: candidateStaffId,
      p_starts_at: startsAt.toISOString(),
      p_customer_name: args.customer.name,
      p_customer_phone: args.customer.phone,
      p_customer_email: args.customer.email,
      p_note: args.customer.note ?? null,
      p_source: "public_booking",
      p_created_by: null,
    });

    if (!error) return { appointmentId: data as string, staffId: candidateStaffId };

    const retryable = error.code === "23P01"
      || error.message.includes("SLOT_JUST_BOOKED")
      || error.message.includes("TIME_BLOCKED")
      || error.message.includes("STAFF_BREAK")
      || error.message.includes("STAFF_NOT_WORKING");
    if (!args.staffId && retryable) {
      lastConflict = true;
      continue;
    }
    if (error.code === "23P01" || error.message.includes("SLOT_JUST_BOOKED")) {
      throw new Error("SLOT_JUST_BOOKED");
    }
    throw error;
  }

  if (lastConflict) throw new Error("SLOT_JUST_BOOKED");
  throw new Error("SLOT_UNAVAILABLE");
}
